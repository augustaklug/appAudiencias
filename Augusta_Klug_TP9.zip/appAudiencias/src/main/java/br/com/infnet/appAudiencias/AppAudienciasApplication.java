package br.com.infnet.appAudiencias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppAudienciasApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppAudienciasApplication.class, args);
	}

}
