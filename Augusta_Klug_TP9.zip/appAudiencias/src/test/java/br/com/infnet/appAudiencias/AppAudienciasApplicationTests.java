package br.com.infnet.appAudiencias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppAudienciasApplicationTests {

	@Test
	void contextLoads() {
	}

}
